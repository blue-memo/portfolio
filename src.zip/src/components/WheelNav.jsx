export default function WheelNav({ sections, activeIdx }) {
  return (
    <nav className="wheel-nav" aria-label="Section navigation">
      {sections.map((s, i) => (
        <button
          key={s.id}
          className={"wn-item" + (i === activeIdx ? " active" : "")}
          onClick={() => document.getElementById(s.id)?.scrollIntoView({ behavior: "smooth" })}
          aria-current={i === activeIdx ? "true" : undefined}
          aria-label={`Go to ${s.label}`}
        >
          <span className="wn-num">{String(i).padStart(2, "0")}</span>
          <span className="wn-dot" />
          <span className="wn-label">{s.label}</span>
        </button>
      ))}
    </nav>
  );
}
